GitHub logo usage conforms to the permitted usage described at https://github.com/logos
