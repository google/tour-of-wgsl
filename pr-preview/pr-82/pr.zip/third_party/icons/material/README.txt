Google Fonts icons downloaded from https://fonts.google.com/icons
